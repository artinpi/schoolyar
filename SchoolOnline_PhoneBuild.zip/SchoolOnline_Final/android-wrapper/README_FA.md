# ساخت APK مدرسه‌یار با Capacitor

## پیش‌نیازها
- Node.js 20+
- Android Studio و Android SDK نصب‌شده
- پیکربندی Firebase در `www/firebase-config.js`

## ساخت پوشهٔ اندروید
از ریشهٔ پروژه اجرا کنید:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

اگر پوشهٔ `android` از قبل وجود دارد، `npx cap add android` را دوباره اجرا نکنید؛ فقط `npx cap sync android` کافی است.

در Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. فایل خروجی معمولاً زیر `android/app/build/outputs/apk/` قرار می‌گیرد.

این مخزن APK از پیش ساخته‌شده ندارد؛ خروجی باید در محیطی با Android SDK ساخته و آزمایش شود. برای انتشار عمومی، شناسهٔ برنامه، امضای Release، سیاست حریم خصوصی، آیکون و آزمون روی چند دستگاه را تنظیم کنید.
